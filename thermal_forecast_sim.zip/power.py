"""Request trace -> per-server GPU power at 10 ms resolution.

Models one rack of 8 inference servers (8x H100 each, one tensor-parallel
model replica per server, e.g. a 70B model). Requests from the public Azure
LLM inference trace are routed to the least-loaded server; each server runs a
simplified vLLM-style continuous-batching loop with chunked prefill.

All 8 GPUs in a server share the same power trace (tensor parallel).
Every number below is an ASSUMPTION, chosen to be plausible for H100 SXM.
"""
import numpy as np
import pandas as pd
from numba import njit

DT = 0.01                 # s, simulation step
N_SERVERS = 8
PREFILL_TOK_S = 30000.0   # prefill throughput per server (tokens/s)
ITER_A = 0.015            # decode iteration time = A + B*batch (s)
ITER_B = 0.0001
MAX_BATCH = 256
P_IDLE = 100.0            # W per GPU
P_PREFILL = 690.0         # W per GPU while doing prefill (near 700 W TDP)
P_DEC_LO = 300.0          # W per GPU decoding small batch
P_DEC_HI = 500.0          # W per GPU decoding batch >= 128


def load_trace(path, copies, jitter_s, shift_mode, seed=0):
    """Return sorted arrival times (s), prompt tokens, output tokens.

    shift_mode='circular': each copy circularly shifted by a random offset
        (independent tenants -> burstiness partly averages out).
    shift_mode='aligned': copies share timestamps plus small jitter
        (correlated bursts -> worst case).
    """
    d = pd.read_csv(path, parse_dates=["TIMESTAMP"])
    t = (d.TIMESTAMP - d.TIMESTAMP.min()).dt.total_seconds().to_numpy()
    span = t.max() + 1.0
    rng = np.random.default_rng(seed)
    ts, ps, gs = [], [], []
    for k in range(copies):
        if shift_mode == "circular":
            tk = (t + rng.uniform(0, span)) % span
        else:
            tk = t + rng.uniform(0, jitter_s, size=len(t))
        ts.append(tk)
        ps.append(d.ContextTokens.to_numpy())
        gs.append(d.GeneratedTokens.to_numpy())
    t = np.concatenate(ts); p = np.concatenate(ps); g = np.concatenate(gs)
    o = np.argsort(t)
    return t[o], p[o].astype(np.float64), np.maximum(g[o], 1).astype(np.float64), span


@njit(cache=True)
def _serve(arr_t, prompt, gen, n_steps, dt, n_srv, pf_rate, ia, ib, max_batch,
           p_idle, p_pre, p_lo, p_hi):
    n_req = arr_t.shape[0]
    power = np.zeros((n_steps, n_srv))
    queued_tok = np.zeros((n_steps, n_srv))     # prefill tokens waiting
    wait = np.full(n_req, -1.0)                 # arrival -> first prefill work
    srv_of = np.zeros(n_req, np.int64)
    # per-server FIFO of request ids awaiting/undergoing prefill
    qbuf = np.zeros((n_srv, n_req), np.int64)
    qhead = np.zeros(n_srv, np.int64); qtail = np.zeros(n_srv, np.int64)
    rem_pf = prompt.copy()
    # running decode sets
    run = np.zeros((n_srv, max_batch), np.int64)
    nrun = np.zeros(n_srv, np.int64)
    prog = np.zeros(n_req)
    qtok = np.zeros(n_srv)
    nxt = 0
    for step in range(n_steps):
        now = step * dt
        # arrivals -> least-loaded routing
        while nxt < n_req and arr_t[nxt] <= now:
            best = 0; bestv = 1e30
            for s in range(n_srv):
                v = qtok[s] + 300.0 * nrun[s]
                if v < bestv:
                    bestv = v; best = s
            qbuf[best, qtail[best]] = nxt; qtail[best] += 1
            qtok[best] += prompt[nxt]; srv_of[nxt] = best
            nxt += 1
        for s in range(n_srv):
            budget = dt
            # chunked prefill, admitted only while batch has room
            while budget > 1e-9 and qhead[s] < qtail[s] and nrun[s] < max_batch:
                r = qbuf[s, qhead[s]]
                if wait[r] < 0:
                    wait[r] = now - arr_t[r]
                need = rem_pf[r] / pf_rate
                use = need if need < budget else budget
                done_tok = use * pf_rate
                rem_pf[r] -= done_tok; qtok[s] -= done_tok; budget -= use
                if rem_pf[r] <= 1e-6:
                    qhead[s] += 1
                    run[s, nrun[s]] = r; nrun[s] += 1
            f_pf = (dt - budget) / dt
            # decode with leftover time
            b = nrun[s]
            if b > 0:
                t_it = ia + ib * b
                adv = budget / t_it
                k = 0
                while k < nrun[s]:
                    r = run[s, k]
                    prog[r] += adv
                    if prog[r] >= gen[r]:
                        nrun[s] -= 1
                        run[s, k] = run[s, nrun[s]]
                    else:
                        k += 1
                frac_b = b / 128.0
                if frac_b > 1.0:
                    frac_b = 1.0
                p_dec = p_lo + (p_hi - p_lo) * frac_b
                power[step, s] = f_pf * p_pre + (1 - f_pf) * p_dec
            else:
                power[step, s] = f_pf * p_pre + (1 - f_pf) * p_idle
            queued_tok[step, s] = qtok[s]
    return power, queued_tok, wait, prompt


def simulate_power(path, copies, shift_mode, jitter_s=0.2, seed=0, duration=None):
    t, p, g, span = load_trace(path, copies, jitter_s, shift_mode, seed)
    dur = duration or span
    n_steps = int(dur / DT)
    power, qtok, wait, prompt = _serve(t, p, g, n_steps, DT, N_SERVERS, PREFILL_TOK_S,
                                       ITER_A, ITER_B, MAX_BATCH, P_IDLE, P_PREFILL,
                                       P_DEC_LO, P_DEC_HI)
    return dict(power=power, qtok=qtok, wait=wait, prompt=prompt, arr=t, dt=DT)
