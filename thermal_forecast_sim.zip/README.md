# Does knowing inference load ahead of time help liquid cooling?

A simulation testing whether a forecast of GPU power (from the inference
request queue, or a perfect forecast of L seconds) lets a rack's cooling loop
run warmer supply water than control that reacts to measured rack power
(Phaidra-style).

## Pipeline
1. `power.py`: the public Azure LLM inference trace (Nov 2023), routed to a rack of
   8 servers × 8 H100s with simplified vLLM-style continuous batching and
   chunked prefill → per-server GPU power every 10 ms.
   - **smooth**: conversation trace, 12 independent copies (mean ~480 W/GPU)
   - **bursty**: code trace, 16 copies arriving together (correlated bursts, saturating)
2. `thermal.py`: die → cold plate → coolant thermal model per GPU (64 GPUs,
   ±10% thermal-resistance spread), pump lag, transport delay, an imperfect
   CDU, and proportional throttling above 85 °C. Four pump controllers:
   - **A**: PI on the hottest GPU's temperature (telemetry delayed 0.5 s)
   - **B**: A + feedforward from measured rack power (delayed 0.5 s)
   - **Q**: A + feedforward from the vLLM prefill queue (the realistic forecast)
   - **C(L)**: A + feedforward from the *true* peak power over the next L seconds (a perfect forecast)
   Feedforward acts as a floor: the PI loop can add flow but never undo pre-cooling.
3. `sweep.py`: tunes each controller's gains on a grid, then bisects for the
   **highest CDU supply-water temperature** that keeps throughput lost to
   throttling ≤ 0.05%. Warmer supply water means more free cooling, which is
   where operators save money.
4. `sens.py`: reruns the bursty case with different hardware assumptions,
   set through environment variables (`TAU_PUMP`, `C_PLATE`, `TAU_TR`, `CDU_G`).

Run: `pip install numba scipy pandas`, put the Azure CSVs in `../data/`, then
`python3 -c "from power import *; ..."` (see how the `.npy` files are produced),
`python3 sweep.py smooth bursty` and `TAU_PUMP=10 python3 sens.py name`.
Each one-hour simulation takes about 0.1 s.

## Results: max supply-water temperature (°C), throttling ≤ 0.05%

| Case | A: PI | B: rack power | Q: queue | C: perfect 2 s | C: perfect 30 s | Ceiling (pump at 100%) |
|---|---|---|---|---|---|---|
| Smooth traffic | 54.7 | 54.7 | 54.7 | 54.7 | 54.7 | 54.7 |
| Bursty, base hardware (pump lag 2 s) | 40.7 | 44.7 | 44.7 | 44.8 | 44.7 | 44.7 |
| Bursty, pump lag 10 s | 30.7 | 42.1 | 42.6 | 43.7 | 44.7 | 44.7 |
| Bursty, plate thermal mass ÷3 | 32.3 | 43.9 | 44.1 | 44.3 | 44.0 | 43.9 |
| Bursty, slow pump + light plate | 21.6 | 35.8 | 37.1 | 40.7 | 43.9 | 43.9 |
| Bursty, sloppy CDU (15 s delay) | 38.1 | 43.9 | 44.0 | 44.1 | 43.4 | 43.2 |

The bisection resolves to about ±0.06 °C, so differences under about 0.2 °C are noise.
Lost throughput is approximated from the power cut while throttling.

**How much warning the queue gives (token-weighted wait from arrival to prefill start):**
- smooth: p50 5 ms, p90 9 ms, p99 19 ms
- bursty: p50 4.3 s, p90 28 s, but only once the servers are already saturated

## Findings
1. **Most of the gain comes from reacting to rack power at all.** B beats plain
   PI by 4–14 °C and, with base hardware, already reaches the physical ceiling.
2. **A forecast only pays when the cooling actuator is slower than the chip
   heats up.** With a 10 s pump lag, or a 10 s pump plus a light cold plate, a
   perfect forecast is worth 2.6–8 °C over B. Otherwise it's worth about 0.
3. **The queue doesn't give that forecast.** At low load the warning is ~10 ms.
   At high load it's seconds, but the GPUs are already flat out by then. The
   queue recovers 0.5–1.2 °C of a possible 2.6–8 °C.
4. Forecasting costs pump energy: more lead means more pre-cooling.

## So what
The idea isn't dead. It's narrowed to one question: **in real deployments, is
the effective cooling actuator (pump, CDU valve, facility loop) much slower
than the chip's thermal response, and is there a signal with several seconds
of real warning?** The queue isn't that signal. Orchestration events
(autoscaling, model loads, batch-job starts, daily traffic patterns) might be.
That's the next experiment.

## Main assumptions (all unverified, vary them)
- Per-GPU power: idle 100 W, decode 300–500 W, prefill 690 W; prefill at 30k tok/s per server
- Die: 30 J/K, 0.025 K/W. Plate: 300 J/K, 0.025 K/W at 1.5 L/min. Pump flow can drop to 30%.
- CDU leaks 30% of delayed return-temperature swings into supply
- Cooling is controlled by pump speed only; supply-temperature control isn't modelled
- Single rack; no grid-level power smoothing (GB300 capacitors would damp bursts further)
