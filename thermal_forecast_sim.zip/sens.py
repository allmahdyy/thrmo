import sys, json, numpy as np
from thermal import max_supply_temp, rmul_vector
from sweep import tune
P=np.load('p_bursty.npy'); Q=np.load('q_bursty.npy'); rm=rmul_vector(8)
out={c:tune(P,Q,c,rm)['t_set'] for c in ['A','B','Q']}
out['C30']=tune(P,Q,'C',rm,30)['t_set']
out['C2']=tune(P,Q,'C',rm,2)['t_set']
out['ceiling']=max_supply_temp(P,'A',rm,kp=0.0,ki=0.0,s0=1.0)['t_set']
print(sys.argv[1], json.dumps({k:round(v,2) for k,v in out.items()}))
