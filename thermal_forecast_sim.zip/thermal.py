"""Rack liquid-cooling loop + four pump controllers.

Per GPU (64 per rack):  die --R_dp-- cold plate --R_conv(flow)-- coolant
Coolant: secondary loop at flow s*m_nom per GPU, pump speed s lags command
(first order, TAU_PUMP). Supply temperature is held by the CDU at T_set, but
return-temperature swings leak through after a transport delay (imperfect CDU
regulation, modelled as a high-passed, delayed disturbance).
Throttling: above T_LIM the GPU cuts its power (and throughput) proportionally.

Controllers act on pump speed only (the fast actuator):
  A  PI on hottest GPU temperature (telemetry delayed TEL_DELAY)
  B  A + feedforward from measured rack power (delayed TEL_DELAY)  ~ Phaidra-style
  C  A + feedforward from max power over the next L seconds         (perfect L-second forecast)
  Q  A + feedforward from a forecast built from the vLLM prefill queue (realistic)
All parameters are ASSUMPTIONS for H100-class direct-to-chip cooling.
"""
import os
import numpy as np
from numba import njit
from scipy.ndimage import maximum_filter1d

DT = 0.01
GPUS_PER_SRV = 8
C_DIE, R_DP = 30.0, 0.025          # J/K, K/W   die+TIM (tau ~0.75 s)
C_PLATE, R_CONV = float(os.environ.get("C_PLATE", 300.0)), 0.025     # J/K, K/W at nominal flow (tau ~7.5 s)
M_NOM, CP = 0.025, 3800.0          # kg/s per GPU at s=1 (1.5 L/min), PG25
S_MIN = 0.3
TAU_PUMP = float(os.environ.get("TAU_PUMP", 2.0))                    # s
PUMP_W_MAX = 700.0                 # rack share of secondary pump power at s=1
T_LIM = 85.0                       # slowdown threshold, degC
T_TARGET = 82.0
TEL_DELAY = 0.5                    # s, telemetry pipeline delay
CTRL_EVERY = 10                    # control update every 0.1 s
TAU_TR, CDU_G, CDU_TAU = float(os.environ.get("TAU_TR", 5.0)), float(os.environ.get("CDU_G", 0.3)), 30.0


@njit(cache=False)
def _ff_speed(p, t_sup, rmul):
    """Smallest pump speed that holds the hottest GPU at T_TARGET in steady state."""
    lo, hi = S_MIN, 1.0
    def temp(s):
        return t_sup + 0.5 * p / (M_NOM * s * CP) + p * rmul * (R_DP + R_CONV * s ** -0.8)
    if temp(hi) > T_TARGET:
        return 1.0
    if temp(lo) <= T_TARGET:
        return lo
    for _ in range(30):
        mid = 0.5 * (lo + hi)
        if temp(mid) > T_TARGET:
            lo = mid
        else:
            hi = mid
    return hi


@njit(cache=False)
def _run(p_req_srv, ff_sig, mode, t_set, rmul, kp, ki, s0):
    """mode 0 = PI only; 1 = PI + feedforward on ff_sig (already delayed/forecast)."""
    n, n_srv = p_req_srv.shape
    ng = n_srv * GPUS_PER_SRV
    td = np.full(ng, t_set + 20.0); tp = np.full(ng, t_set + 15.0)
    s_cmd = 0.6; s = 0.6; integ = 0.0
    d_tel = int(TEL_DELAY / DT); d_tr = int(TAU_TR / DT)
    hot_hist = np.full(n, t_set + 20.0)
    ret_hist = np.full(n, t_set + 5.0)
    lp = t_set + 5.0; ret_base_set = False
    t_sup = t_set
    lost = 0.0; req = 0.0; above = 0; pump_e = 0.0; tmax = 0.0
    for k in range(n):
        # CDU supply disturbance from delayed return temperature
        if k >= d_tr:
            rd = ret_hist[k - d_tr]
            lp += (rd - lp) * DT / CDU_TAU
            t_sup = t_set + CDU_G * (rd - lp)
        s += (s_cmd - s) * DT / TAU_PUMP
        m = M_NOM * s
        rconv_s = R_CONV * s ** -0.8
        q_tot = 0.0; hot = -1e9
        for g in range(ng):
            pr = p_req_srv[k, g // GPUS_PER_SRV]
            f = 1.0 - 0.1 * (td[g] - T_LIM)
            if f > 1.0: f = 1.0
            if f < 0.5: f = 0.5
            pa = pr * f
            lost += pr - pa; req += pr
            tc = t_sup + 0.5 * pa / (m * CP)
            q_dp = (td[g] - tp[g]) / (R_DP * rmul[g])
            q_cv = (tp[g] - tc) / (rconv_s * rmul[g])
            td[g] += (pa - q_dp) * DT / C_DIE
            tp[g] += (q_dp - q_cv) * DT / C_PLATE
            q_tot += pa
            if td[g] > hot: hot = td[g]
            if td[g] > T_LIM: above += 1
        if hot > tmax: tmax = hot
        hot_hist[k] = hot
        ret_hist[k] = t_sup + q_tot / (M_NOM * s * ng * CP)
        pump_e += PUMP_W_MAX * s ** 3 * DT
        if k % CTRL_EVERY == 0:
            meas = hot_hist[k - d_tel] if k >= d_tel else hot
            e = meas - T_TARGET
            integ += e * CTRL_EVERY * DT
            if integ > 50.0: integ = 50.0
            if integ < -50.0: integ = -50.0
            sc = s0 + kp * e + ki * integ
            if mode == 1:
                # feedforward is a floor: PI can add flow but never undo pre-cooling
                ff = _ff_speed(ff_sig[k], t_sup, rmul.max())
                if ff > sc:
                    sc = ff
            if sc > 1.0:
                sc = 1.0; integ -= e * CTRL_EVERY * DT  # anti-windup
            if sc < S_MIN:
                sc = S_MIN; integ -= e * CTRL_EVERY * DT
            s_cmd = sc
    T = n * DT
    return lost / req, above / (n * ng), pump_e / T, tmax


def rmul_vector(n_srv, seed=1):
    """+-10% GPU-to-GPU variation in thermal resistance (TIM, flow split)."""
    return np.random.default_rng(seed).uniform(0.9, 1.1, n_srv * GPUS_PER_SRV)


def ff_signal(p_srv, kind, lead_s=0.0, qtok=None, pf_rate=30000.0, p_pre=690.0):
    """Per-step feedforward power for the hottest server."""
    n = p_srv.shape[0]
    if kind == "measured":           # B: what rack power telemetry shows now
        d = int(TEL_DELAY / DT)
        sig = np.vstack([np.repeat(p_srv[:1], d, 0), p_srv[:-d]]).max(1)
    elif kind == "forecast":         # C: perfect knowledge of the next lead_s seconds
        w = max(1, int(lead_s / DT))
        fwd = maximum_filter1d(p_srv, size=w, axis=0, origin=-(w // 2), mode="nearest")
        sig = fwd.max(1)
    elif kind == "queue":            # Q: queued prefill tokens => prefill power ahead
        d = int(TEL_DELAY / DT)
        meas = np.vstack([np.repeat(p_srv[:1], d, 0), p_srv[:-d]])
        busy = qtok > pf_rate * 0.05     # >50 ms of prefill waiting
        sig = np.where(busy, np.maximum(meas, p_pre), meas).max(1)
    return np.ascontiguousarray(sig)


CTRL_PARAMS = {}


def run(p_srv, ctrl, t_set, rmul, lead_s=0.0, qtok=None, kp=0.05, ki=0.01, s0=0.6):
    if ctrl == "A":
        sig = np.zeros(p_srv.shape[0]); mode = 0
    else:
        kind = {"B": "measured", "C": "forecast", "Q": "queue"}[ctrl]
        sig = ff_signal(p_srv, kind, lead_s, qtok); mode = 1
    loss, above, pump_w, tmax = _run(np.ascontiguousarray(p_srv), sig, mode, t_set, rmul, kp, ki, s0)
    return dict(loss=loss, above=above, pump_w=pump_w, tmax=tmax)


def max_supply_temp(p_srv, ctrl, rmul, loss_budget=5e-4, lead_s=0.0, qtok=None, lo=5.0, hi=65.0, **kw):
    """Highest CDU supply setpoint that keeps throttled throughput under loss_budget."""
    for _ in range(10):
        mid = 0.5 * (lo + hi)
        if run(p_srv, ctrl, mid, rmul, lead_s, qtok, **kw)["loss"] <= loss_budget:
            lo = mid
        else:
            hi = mid
    r = run(p_srv, ctrl, lo, rmul, lead_s, qtok, **kw)
    r["t_set"] = lo
    return r
