"""Tune each controller fairly, then find the highest supply-water setpoint it can
run at while keeping throttling losses under budget. Sweep forecast lead time."""
import json, itertools
import numpy as np
from thermal import max_supply_temp, rmul_vector, run

LEADS = [0.5, 1, 2, 5, 10, 30]
GRID = dict(kp=[0.05, 0.1, 0.2], ki=[0.003, 0.01], s0=[0.5, 0.8])


def tune(P, Q, ctrl, rm, lead=0.0):
    best = None
    s0s = GRID["s0"]
    for kp, ki, s0 in itertools.product(GRID["kp"], GRID["ki"], s0s):
        r = max_supply_temp(P, ctrl, rm, lead_s=lead, qtok=Q, kp=kp, ki=ki, s0=s0)
        if best is None or r["t_set"] > best["t_set"] + 1e-3 or (
                abs(r["t_set"] - best["t_set"]) < 1e-3 and r["pump_w"] < best["pump_w"]):
            best = dict(r, kp=kp, ki=ki, s0=s0)
    return best


def main():
    rm = rmul_vector(8)
    out = {}
    import sys
    for scen in sys.argv[1:]:
        P = np.load(f"p_{scen}.npy"); Q = np.load(f"q_{scen}.npy")
        res = {}
        res["A"] = tune(P, Q, "A", rm)
        res["B"] = tune(P, Q, "B", rm)
        res["Q"] = tune(P, Q, "Q", rm)
        res["C"] = {str(L): tune(P, Q, "C", rm, L) for L in LEADS}
        # physical ceiling: pump pinned at 100 %
        r = max_supply_temp(P, "A", rm, kp=0.0, ki=0.0, s0=1.0); res["full_pump"] = r
        out[scen] = res
        print(scen, {k: (round(v["t_set"], 2), round(v["pump_w"])) for k, v in res.items() if k != "C"})
        print("  C:", {L: (round(v["t_set"], 2), round(v["pump_w"])) for L, v in res["C"].items()})
    json.dump(out, open(f"results_{scen}.json", "w"), indent=1)


if __name__ == "__main__":
    main()
